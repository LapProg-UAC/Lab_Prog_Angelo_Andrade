import random
from datetime import datetime

# calc paridade (0 = par, 1 = impar)
def bit_paridade(n):
    return bin(n).count("1") % 2


# gerar numeros
random.seed(datetime.now().timestamp())

k = random.randint(51, 64)  # qtd nums

nums = []
for _ in range(k):
    nums.append(random.randint(0, 127))


# paridades
pars = []
for n in nums:
    pars.append(bit_paridade(n))


# guardar ficheiros
with open("numeros.txt", "w") as f:
    for n in nums:
        f.write(str(n) + "\n")

with open("paridade.txt", "w") as f:
    for p in pars:
        f.write(str(p) + "\n")


# copiar e estragar alguns (simular erro)
nums_err = nums.copy()

for i in range(len(nums_err)):
    if random.random() < 0.3:  # nem todos levam erro
        b = random.randint(0, 7)  # bit random
        nums_err[i] ^= (1 << b)  # flip no bit


# guardar nums com erro
with open("numeros_erro.txt", "w") as f:
    for n in nums_err:
        f.write(str(n) + "\n")


# recalcular paridade
pars_err = []
for n in nums_err:
    pars_err.append(bit_paridade(n))

with open("paridade_erro.txt", "w") as f:
    for p in pars_err:
        f.write(str(p) + "\n")


# ver onde deu erro
print("erros:")

for i in range(k):
    if pars[i] != pars_err[i]:
        print(f"linha {i+1} -> {nums[i]} virou {nums_err[i]}")