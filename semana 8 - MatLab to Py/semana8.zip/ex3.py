import numpy as np                      
from scipy.fft import fft, fftfreq      
import matplotlib.pyplot as plt         

# Parâmetros
fs = 1000                               
t = np.arange(0, 1, 1/fs)               # Vetor de tempo de 0 a 1 s com passo 1/fs

# Sinal
sig = (                                 
    np.sin(2*np.pi*50*t)                #   componente de 50 Hz com amplitude 1
    + 0.5*np.sin(2*np.pi*120*t))         #   componente de 120 Hz com amplitude 0.5


# FFT
Y = np.abs(fft(sig))                    # Calcula a FFT do sinal

# Frequências
N = len(sig)                            
freqs = fftfreq(N, 1/fs)                # Vetor de frequências associado à FFT

# Metade positiva
half = N // 2                           
freqs_pos = freqs[:half]                # Mantém apenas positivas
Y_pos = Y[:half] * 2 / N                # Normaliza a amplitude e multiplica por 2

Y_pos[0] /= 2                           
if N % 2 == 0:                          
    Y_pos[-1] /= 2                      # Correcao de nyquist?

plt.figure(figsize=(8, 4))              
plt.plot(freqs_pos, Y_pos, 'b-', linewidth=2)                   
plt.xlabel('Frequência (Hz)')           
plt.ylabel('Amplitude')                 
plt.title('FFT do sinal')               
plt.grid(True)                          
plt.show()                              