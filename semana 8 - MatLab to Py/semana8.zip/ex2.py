import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

X, Y = np.meshgrid(np.linspace(-3,3,100), np.linspace(-3,3,100))   # Cria uma grelha 2D de 100x100 pontos no intervalo [-3, 3] para X e Y
Z = np.sin(np.sqrt(X**2 + Y**2))                                   # Calcula Z aplicando a função sin(sqrt(X^2 + Y^2)) ponto a ponto

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')                         # Configura uma figura 3D e desenha a superfície com o mapa de cores 'viridis'.
ax.plot_surface(X, Y, Z, cmap='viridis')

plt.tight_layout()
fig.savefig('surface.png')                                         # Ajusta o layout e guarda a imagem resultante no ficheiro 'surface.png'.
