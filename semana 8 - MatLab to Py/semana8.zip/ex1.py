import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0,2*np.pi,400)     # Cria 400 pontos igualmente espaçados entre 0 e 2Pi usando np
y = np.sin(x)                      # Calcula o valor da função seno para cada um dos pontos.

plt.plot(x,y)                      # Utiliza o matplotlib para formar e mostrar o gráfico resultante.
plt.show()

# gera um gráfico da função seno no intervalo de 0 a 2π.

