import pytest
from funcao_doctest import gerar_f


def test_cinco():
    assert gerar_f(5) == [0, 1, 1, 4, 7]


def test_zero():
    assert gerar_f(0) == [0]


def test_negativo():
    with pytest.raises(ValueError):
        gerar_f(-1)


def test_tipo():
    with pytest.raises(ValueError):
        gerar_f("abc")