import unittest
from funcao_doctest import gerar_f


class TestGerarF(unittest.TestCase):

    def test_zero(self):
        self.assertEqual(gerar_f(0), [0])

    def test_um(self):
        self.assertEqual(gerar_f(1), [0])

    def test_cinco(self):
        self.assertEqual(gerar_f(5), [0, 1, 1, 4, 7])

    def test_negativo(self):
        with self.assertRaises(ValueError):
            gerar_f(-1)

    def test_tipo(self):
        with self.assertRaises(ValueError):
            gerar_f("abc")


if __name__ == "__main__":
    unittest.main()